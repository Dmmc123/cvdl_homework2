
CVDL Homework 2 - v1 Avocado_vs_Cava
==============================

This dataset was exported via roboflow.ai on December 1, 2021 at 10:01 PM GMT

It includes 96 images.
Plushies are annotated in COCO format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


